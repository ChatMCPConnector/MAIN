"""GLM to OpenAI-compatible API proxy."""

__all__ = ["__version__"]

__version__ = "0.1.0"
