from glm2api.__main__ import main

if __name__ == "__main__":
    raise SystemExit(main())
