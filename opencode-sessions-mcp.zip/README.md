# opencode-sessions MCP Server

Ein schlanker, lokaler **Model Context Protocol (MCP)** Server zur blitzschnellen Verwaltung, Analyse, Durchsuchung und Bereinigung von **opencode**-Sessions direkt auf SQLite-Datenbankebene.

---

## 1. Warum existiert dieses MCP?

Standardmäßig speichert opencode den gesamten Verlauf (Sessions, Messages, Snapshots, Parts, Todos, Event-Streams) in einer lokalen SQLite-Datenbank (`~/.local/share/opencode/opencode.db`).

Mit der Zeit führt dies zu zwei Problemen:
1. **Träge CLI/API:** Das Löschen von Dutzenden oder Hunderten alten Sessions über CLI-Umwege oder Menüs ist extrem langsam.
2. **Datenbank-Aufblähung (Orphan Events):** opencode erzeugt pro Interaktion viele Event-Einträge (`event`, `event_sequence`). Werden Sessions gelöscht, bleiben diese Events oft als Dateileichen zurück. Datenbanken wachsen so schnell auf Hunderte Megabyte an.

Dieses MCP setzt direkt an der SQLite-Schicht an: Es liest, durchsucht und löscht Sessions in Millisekunden, säubert verwaiste Event-Streams und schrumpft die Datenbank per `VACUUM` (in der Praxis oft von über 500 MB auf unter 2 MB).

---

## 2. Technische Architektur: Wie funktioniert das MCP?

### Zero Dependencies (Kein `npm install`)
Das Tool setzt bewusst auf **reines Node.js (ab Version 18)** unter ausschließlicher Nutzung eingebauter Standardmodule:
- `node:child_process` (`spawnSync`)
- `node:fs`
- `node:os`
- `node:path`

Es werden **keine externen npm-Pakete** und keine nativen C++-SQLite-Module benötigt. Für die Datenbank-Operationen wird das im System vorhandene `sqlite3`-Kommandozeilentool mit `-json -batch` genutzt. Dadurch ist der Server auf jedem Rechner ohne Build-Tools sofort lauffähig.

### MCP-Kommunikation via stdio (JSON-RPC 2.0)
Der Server kommuniziert über Standard-Ein-/Ausgabe (`process.stdin` / `process.stdout`) mit Zeilen-getrenntem JSON-RPC 2.0:
- Handshake & Lifecycle: `initialize`, `notifications/initialized`, `ping`
- Tool-Discovery: `tools/list`
- Tool-Ausführung: `tools/call`

### Datenbankpfad-Ermittlung
Das Skript ermittelt die SQLite-Datenbank in folgender Reihenfolge:
1. Umgebungsvariable `OPENCODE_DB` (falls gesetzt, für Custom-Pfade oder Tests).
2. Standardpfad: `~/.local/share/opencode/opencode.db`.

---

## 3. Sicherheits- & Schutzmechanismen

Um zu verhindern, dass ein KI-Agent versehentlich seine eigene Sitzung oder parallel laufende Aufgaben beendet, verfügt das MCP über mehrstufige Sicherheitsnetze:

1. **Schutz der aktuellen Sitzung (Caller-Protection):**
   - Das MCP ermittelt über `OPENCODE_PID` bzw. den aktuellen Prozess-CWD die neueste Session im Arbeitsverzeichnis.
   - Diese Session wird **niemals** gelöscht (`is_current_session: true`).

2. **Schutz aktiver Prozesse (Kill-Schutz):**
   - Unter Linux analysiert das MCP `/proc`, um laufende `opencode`-Prozesse und deren Arbeitsverzeichnisse (`/proc/<pid>/cwd`) zu identifizieren.
   - Sessions mit aktiven Prozessen werden automatisch geschützt (`keep_active: true`, Standard).

3. **Schutz geteilter Sitzungen:**
   - Sessions, für die ein Share-Link generiert wurde (`session_share`), werden standardmäßig geschützt (`keep_shared: false`).

4. **Explizites Bestätigungs-Flag:**
   - Der Löschbefehl `delete_sessions` bricht sofort ab, wenn nicht explizit `confirm: true` übergeben wird.

5. **Trockenlauf (`delete_preview`):**
   - Ermöglicht dem Benutzer oder Agenten vorab genau einzusehen, welche Sessions gelöscht würden und welche durch Filter/Schutzregeln verschont bleiben.

---

## 4. Datenbank-Schema & Löschkaskade

Beim Löschen werden Fremdschlüssel-Abhängigkeiten in einer atomaren SQLite-Transaktion aufgelöst:

```text
session
 ├── message
 │    └── part
 ├── session_message
 ├── session_input
 ├── session_context_epoch
 ├── session_share
 ├── todo
 ├── event
 └── event_sequence
```

Im Anschluss an die Session-Löschung führt das Tool folgenden Bereinigungsschritt aus:
```sql
DELETE FROM event WHERE aggregate_id LIKE 'ses_%' AND aggregate_id NOT IN (SELECT id FROM session);
DELETE FROM event_sequence WHERE aggregate_id LIKE 'ses_%' AND aggregate_id NOT IN (SELECT id FROM session);
VACUUM;
```
Damit wird die SQLite-Datei auf der Festplatte physisch defragmentiert und verkleinert.

---

## 5. Die 6 bereitgestellten Tools

### 1. `db_stats`
Liefert Statusinformationen zur opencode-Datenbank:
- `db_path`: Pfad zur genutzten Datenbankdatei.
- `db_size_mb`: Physische Dateigröße in Megabyte.
- Zähler für: `sessions`, `messages`, `parts`, `events`.
- `active_opencode_processes`: Anzahl laufender opencode-Prozesse.
- `current_session_id`: ID der aktuell erkannten Sitzung.

### 2. `list_sessions`
Listet Sessions chronologisch sortiert auf (neueste zuerst).
- **Parameter:**
  - `directory` (string, optional): Filtert nach Projektverzeichnis (z. B. `/workspaces/mein-projekt`).
  - `project` (string, optional): Filtert nach Worktree-Pfad.
  - `limit` (number, optional): Maximale Anzahl (Default: 100, Max: 500).
- **Rückgabe je Session:** `id`, `title`, `directory`, `agent`, `model`, `messages`, `created`, `updated`, `age_days`, `active`, `is_current_session`.

### 3. `session_info`
Gibt Detaildaten zu einer spezifischen Session zurück.
- **Parameter:**
  - `session_id` (string, Pflicht): Die ID der Sitzung (`ses_...`).
- **Rückgabe:** Modell, Kosten, Token-Aufschlüsselung (Input, Output, Reasoning), Nachrichtenanzahl, Todo-Anzahl, Share-URL.

### 4. `search_sessions`
Volltextsuche über Session-Titel und den eigentlichen Inhalt aller Nachrichten (`part.data`).
- **Parameter:**
  - `query` (string, Pflicht): Suchbegriff.
  - `limit` (number, optional): Trefferbegrenzung (Default: 30, Max: 100).

### 5. `delete_preview`
Gefahrenfreier Trockenlauf für `delete_sessions`.
- **Parameter:**
  - `older_than_days` (number, optional): Nur Sessions älter als X Tage berücksichtigen.
  - `directory` (string, optional): Nur Sessions aus diesem Verzeichnis.
  - `keep_ids` (string[], optional): Liste explizit zu schützender IDs.
  - `keep_active` (boolean, optional, Default: `true`): Aktive Sessions schützen.
  - `keep_shared` (boolean, optional, Default: `false`): Wenn `true`, werden auch geteilte Sessions als Löschkandidaten markiert.
- **Rückgabe:** `would_delete`, `would_keep`, Liste der `victims` und geschützten IDs.

### 6. `delete_sessions`
Führt die eigentliche Löschung durch.
- **Parameter:**
  - `confirm` (boolean, Pflicht): Muss `true` sein!
  - `older_than_days` (number, optional)
  - `directory` (string, optional)
  - `delete_ids` (string[], optional): Gezielte Liste von IDs zum Löschen.
  - `keep_ids` (string[], optional)
  - `keep_active` (boolean, optional, Default: `true`)
  - `keep_shared` (boolean, optional, Default: `false`)

---

## 6. Installation & Einrichtung auf einem anderen Rechner

### Schritt 1: Voraussetzungen
Stelle sicher, dass **Node.js (>= 18)** und das **`sqlite3` CLI** vorhanden sind:
```bash
# Ubuntu / Debian
sudo apt update && sudo apt install -y nodejs sqlite3

# macOS (Homebrew)
brew install node sqlite3

# Arch Linux
sudo pacman -S nodejs sqlite
```

### Schritt 2: Skript ablegen
Entpacke die Datei an einen zentralen Ort, z. B. in die opencode-Benutzerkonfiguration:
```bash
mkdir -p ~/.config/opencode/mcp
cp opencode-sessions-mcp.js ~/.config/opencode/mcp/opencode-sessions-mcp.js
chmod +x ~/.config/opencode/mcp/opencode-sessions-mcp.js
```

### Schritt 3: In opencode konfigurieren
Öffne oder erstelle deine opencode-Konfigurationsdatei:
- **Global:** `~/.config/opencode/opencode.json`
- **Oder lokal im Projekt:** `<dein-repo>/.opencode/opencode.json`

Füge den `mcp`-Block hinzu:
```json
{
  "mcp": {
    "opencode-sessions": {
      "type": "local",
      "command": [
        "node",
        "/ABSOLUTER/PFAD/ZU/.config/opencode/mcp/opencode-sessions-mcp.js"
      ],
      "enabled": true,
      "environment": {
        // Nur nötig, wenn die DB nicht unter ~/.local/share/opencode/opencode.db liegt:
        // "OPENCODE_DB": "/pfad/zu/deiner/opencode.db"
      }
    }
  }
}
```
*(Wichtig: Den absoluten Pfad zu `node` bzw. zum Skript verwenden).*

### Schritt 4: Testen
Im Terminal prüfen, ob das MCP reagiert:
```bash
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | node ~/.config/opencode/mcp/opencode-sessions-mcp.js
```
Es sollte eine JSON-Antwort mit allen 6 Tools erscheinen.

Sobald du opencode startest, erkennt es das MCP automatisch. Du kannst den Agenten dann direkt bitten:
- *„Zeig mir die Session-Statistiken über db_stats.“*
- *„Welche Sessions sind älter als 14 Tage? Mach eine delete_preview.“*
